<?php

//user pressed 'Generate' button
if (isset($_POST['Generate']))
{
	require('class.PDF.php');
	
	//create the pdf
	$pdf = new PDF();
	$pdf->init();
				
	//set properties
	$pdf->firstname_client = $_POST['firstname_client'];
	$pdf->lastname_client = $_POST['lastname_client'];
	$pdf->zip_client = $_POST['zip_client'];
	$pdf->location_client = $_POST['location_client'];
	$pdf->firstname_service = $_POST['firstname_service'];
	$pdf->lastname_service = $_POST['lastname_service'];
	$pdf->zip_service = $_POST['zip_service'];
	$pdf->location_service = $_POST['location_service'];

	$pdf->printAll();	

	//display pdf file
	$file = $pdf->Output("ManiMano-Quittung.pdf", "I");	
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Form Input</title>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<form name="pdf_generator" method="POST" action="<?php $PHP_SELF ?>">
<table width="50%" border="0">
  <caption>&nbsp;
  </caption>
  <tr>
    <th width="39%" scope="row"><div align="left">Client Firstname</div></th>
    <td width="4%">:</td>
    <td width="57%"><input type="text" name="firstname_client" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Client Lastname </div></th>
    <td>:</td>
    <td><input type="text" name="lastname_client" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Client Zip </div></th>
    <td>:</td>
    <td><input type="text" name="zip_client" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Client Location </div></th>
    <td>:</td>
    <td><input type="text" name="location_client" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Service Firstname</div></th>
    <td>:</td>
    <td><input type="text" name="firstname_service" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left"> Service Lastname </div></th>
    <td>:</td>
    <td><input type="text" name="lastname_service" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Service Zip </div></th>
    <td>:</td>
    <td><input type="text" name="zip_service" /></td>
  </tr>
  <tr>
    <th scope="row"><div align="left">Service Location </div></th>
    <td>:</td>
    <td><input type="text" name="location_service" /></td>
  </tr>
  <tr>
    <th colspan="3" scope="row"><div align="left"></div></th>
  </tr>
</table>
<input type="submit" name="Generate" value="Generate" />
</form>
</body>
</html>
