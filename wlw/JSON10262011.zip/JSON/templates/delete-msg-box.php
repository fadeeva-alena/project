<?php
/*
* 	Used to display result after deleting via flexigrid.
*	Called by:	$('.system-message').fadeIn(1000).css({ display:"block" });
*/
?>
    <div id="system-message" class="system-message" style="display:none;">
        <div class="info">
            <div class="message" id="del-result">&nbsp;</div>
        </div>
    </div>
