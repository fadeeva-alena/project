<?php
	if ($transparent_bg == 1){
?>
	<style>
		#content{
			background-color:transparent;
			border:0px;
		}
	</style>
<?php
	}
?>