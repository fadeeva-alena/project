		<div class="clr"></div>
	</div>
   
    <div id="footer" style="background:white;padding-top:20px;padding-bottom:10px;">
   	  <div><?php echo $config['website']['copyright']?></div>
       
      </div>
	</div>
</div>
</body>
</html>