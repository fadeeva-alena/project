<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo WEBSITE_NAME?></title>
<link rel="icon" href="images/favicon.ico" type="image/x-icon" />
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="<?php echo CSS?>core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS?>general.css" rel="stylesheet" type="text/css" />
<script src="<?php echo PLUGINS?>jquery/jquery.js" type="text/javascript" language="Javascript"></script>
<script src="<?php echo PLUGINS?>jquery/jquery.curvycorners.js" type="text/javascript" language="Javascript"></script>
<script src="<?php echo JS?>/forgotpassword.js" type="text/javascript" language="Javascript"></script>
</head>
<body>
<div id="login-container">	
  	<div class="login-content"> 
        <form method="post" id="frmForgotPassword" action="">
            <div class="login-content-main">	
                <div class="login-logo"><img src="images/login-logo.png" /></div>
                <h2><?php
		
			$sqlfield = mysql_query("select * from t_field_names where id=275");
		
		$rowfield = mysql_fetch_array($sqlfield);
		if ($_SESSION[WEBSITE_ALIAS]['language'] ==1){
			echo $rowfield['fieldname_de'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==2){
			echo $rowfield['fieldname_eng'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==3){
			echo $rowfield['fieldname_fr'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==4){
			echo $rowfield['fieldname_it'];
		}
		?></h2>
               
                <label><?php
		
			$sqlfield = mysql_query("select * from t_field_names where id=276");
		
		$rowfield = mysql_fetch_array($sqlfield);
		if ($_SESSION[WEBSITE_ALIAS]['language'] ==1){
			echo $rowfield['fieldname_de'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==2){
			echo $rowfield['fieldname_eng'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==3){
			echo $rowfield['fieldname_fr'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==4){
			echo $rowfield['fieldname_it'];
		}
		?></label>
               
                
				
				 <div class="send-button">
				 <br />
				 <div style="float:left;margin-top:4px;">
					<a href="index.php?option=login"><?php
		
			$sqlfield = mysql_query("select * from t_field_names where id=227");
		
		$rowfield = mysql_fetch_array($sqlfield);
		if ($_SESSION[WEBSITE_ALIAS]['language'] ==1){
			echo $rowfield['fieldname_de'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==2){
			echo $rowfield['fieldname_eng'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==3){
			echo $rowfield['fieldname_fr'];
		}elseif ($_SESSION[WEBSITE_ALIAS]['language'] ==4){
			echo $rowfield['fieldname_it'];
		}
		?></a>&nbsp;
				</div>
				 </div>
				 
                <div id="login-indicator">
                    <span id="login-indicator-msg" style="display:none"></span>
                </div>
				
                <div class="clr"></div>
                
            </div>
        </form>
        <div id="login-credit"><?php echo $conf['website']['copyright']?></div>
       
        <div class="clr"></div>
    </div>
</div>
</body>
</html>
